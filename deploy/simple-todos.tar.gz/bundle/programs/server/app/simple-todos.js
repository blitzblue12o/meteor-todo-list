(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// simple-todos.js                                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
                                                                       //
Tasks = new Mongo.Collection("tasks");                                 // 3
                                                                       //
if (Meteor.isClient) {                                                 // 7
                                                                       //
  // This code only runs on the client                                 //
                                                                       //
  Template.body.helpers({                                              // 11
                                                                       //
    tasks: function () {                                               // 13
                                                                       //
      // Show newest tasks at the top                                  //
                                                                       //
      return Tasks.find({}, { sort: { createdAt: -1 } });              // 17
    }                                                                  //
                                                                       //
  });                                                                  //
                                                                       //
  Template.body.events({                                               // 23
                                                                       //
    "submit .new-task": function (event) {                             // 25
                                                                       //
      // Prevent default browser form submit                           //
                                                                       //
      event.preventDefault();                                          // 29
                                                                       //
      // Get value from form element                                   //
                                                                       //
      var text = event.target.text.value;                              // 35
                                                                       //
      // Insert a task into the collection                             //
                                                                       //
      Tasks.insert({                                                   // 41
                                                                       //
        text: text,                                                    // 43
                                                                       //
        createdAt: new Date() // current time                          // 45
                                                                       //
      });                                                              //
                                                                       //
      // Clear form                                                    //
                                                                       //
      event.target.text.value = "";                                    // 53
    }                                                                  //
                                                                       //
  });                                                                  //
                                                                       //
  Template.task.events({                                               // 59
                                                                       //
    "click .toggle-checked": function () {                             // 61
                                                                       //
      // Set the checked property to the opposite of its current value
                                                                       //
      Tasks.update(this._id, {                                         // 65
                                                                       //
        $set: { checked: !this.checked }                               // 67
                                                                       //
      });                                                              //
    },                                                                 //
                                                                       //
    "click .delete": function () {                                     // 73
                                                                       //
      Tasks.remove(this._id);                                          // 75
    }                                                                  //
                                                                       //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=simple-todos.js.map
